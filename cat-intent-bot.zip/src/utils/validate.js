import { z } from 'zod';
export const intentRowSchema = z.object({
  EditType: z.string().min(1)
}).passthrough();
export function validateRows(rows){ return rows.map(r => intentRowSchema.parse(r)); }
