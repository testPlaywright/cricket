import { Router } from 'express';
import XlsxPopulate from 'xlsx-populate';

const router = Router();

const HEADERS = [
  "PDLM Template Row #","Edit Type","BOM Analyst Attention Flag","List IDs",
  "LOB Codes to Apply","Exclusion LOB Codes to Apply","PEX LOB Codes to Apply",
  "Effective Date","Thru Date","Apply Monthly Rolling Dates",
  "Product Type (NDC, GPI)","Product ID","MSC","Coverage Decision",
  "Drug Status","OTC","Pckg","ROA","GPI List Edit","Use Benefit Reset",
  "Drug Status Table","Message Code","Message Text","Message Type",
  "CT Logic","CT Effective Date","CT Thru Date","CT Schedule ID","Bypass CT",
  "Sequence","Age Min","Age Min Unit","Age Max","Age Max Unit","Gender",
  "Bypass Drug Status","Bypass MSC","Mandate States","MandateOption",
  "Mandate Instructions","TOC Batch Lists","Clinical Rule",
  "31 Days and Under","31 Days and Under PQE","31 Days and Under PQE Max",
  "35 Days and Over","35 Days and Over PQE","35 Days and Over PQE Max",
  "P&G 120 Days Supply Limit","P&G 120 Days PQE","P&G 120 Days PQE Max",
  "Specialty","Client Options","Dx2Rx List","Dx2Rx List Qualifier",
  "Dx2Rx List Status","Dx2Rx Message Schedule","Dx2Rx Message Schedule Type"
];

function toKey(s){ return String(s||'').toLowerCase().replace(/[^a-z0-9]/g,''); }

async function buildWorkbook(rows = []){
  const wb = await XlsxPopulate.fromBlankAsync();
  const ws = wb.addSheet('CAT Automated');
  wb.deleteSheet('Sheet1');

  // Row 1-2 (top band minimal)
  ws.cell(1,1).value('Segment').style({bold:true}); ws.cell(1,2).value('E&I');
  ws.cell(2,1).value('Version').style({bold:true}); ws.cell(2,2).value('V3.2');

  // Row 4 numbers
  HEADERS.forEach((_,i)=> ws.cell(4,i+1).value(i+1).style({bold:true}));

  // Row 9 headers
  HEADERS.forEach((h,i)=> ws.cell(9,i+1).value(h).style({bold:true}));

  // Write rows at 10+ by header-name match
  const start = 10;
  rows.forEach((r,i)=>{
    const rowIdx = start + i;
    HEADERS.forEach((h,ci)=>{
      const want = toKey(h);
      let val = '';
      for (const [k,v] of Object.entries(r||{})){
        if (toKey(k) === want) { val = v; break; }
      }
      ws.cell(rowIdx, ci+1).value(val ?? '');
    });
  });
  return wb.outputAsync();
}

// POST /templates/generate  => returns XLSX download
router.post('/generate', async (req, res) => {
  try{
    const rows = Array.isArray(req.body?.rows) ? req.body.rows : [];
    const filename = req.body?.fileName || 'CLINICAL_INTENT.xlsx';
    const buf = await buildWorkbook(rows);
    res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition',`attachment; filename="${filename}"`);
    res.send(Buffer.from(buf));
  }catch(e){
    res.status(500).json({ error: String(e?.message || e) });
  }
});

// POST /templates/create-ticket  => returns mock id
router.post('/create-ticket', async (_req,res)=>{
  const id = 'CAT' + Math.floor(100000000+Math.random()*899999999);
  res.json({ ok:true, ticketId:id });
});

export default router;
