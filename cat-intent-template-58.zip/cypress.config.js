const { defineConfig } = require('cypress');
const path = require('path');
const cucumber = require('cypress-cucumber-preprocessor').default;

const { makeTemplate58FromScratch, appendRows58 } = require('./src/templateBuilder');

module.exports = defineConfig({
  e2e: {
    specPattern: 'cypress/e2e/**/*.feature',
    supportFile: 'cypress/support/e2e.js',
    chromeWebSecurity: false,
    experimentalRunAllSpecs: true,
    experimentalSessionAndOrigin: true,

    setupNodeEvents(on, config) {
      // cucumber
      on('file:preprocessor', cucumber());

      // custom tasks
      on('task', {
        async 'template:build'({ outName = 'CLINICAL_INTENT.xlsx' } = {}) {
          const outDir = path.join(__dirname, 'cypress', 'downloads');
          const fullPath = await makeTemplate58FromScratch(outDir, outName);
          return { outDir, outName, fullPath };
        },
        async 'template:append'({ filePath, rows = [] }) {
          await appendRows58(filePath, rows);
          return { fullPath: filePath, appended: rows.length };
        }
      });

      return config;
    }
  }
});