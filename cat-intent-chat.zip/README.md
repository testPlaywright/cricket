# CAT Intent Chat (Tiny React)

A tiny React chat-like widget that talks to your **CAT Intent Bot**.

## Quick start
```bash
npm i
cp .env.example .env           # set VITE_BOT_BASE to your bot service
npm run dev
```

Open http://localhost:5173 and try **Generate XLSX** or **Create Ticket**.

## How it works
- Collects a few required/optional fields.
- Calls:
  - `POST ${VITE_BOT_BASE}/templates/clinical-intent` → returns Excel (download link)
  - `POST ${VITE_BOT_BASE}/tickets` → returns `{ ticketId }`

To deploy inside CAT UI, mount `<ChatWidget/>` in your page or lazy-load this mini app in an iframe.
