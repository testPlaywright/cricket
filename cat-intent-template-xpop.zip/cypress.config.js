const { defineConfig } = require('cypress');
const path = require('path');
const { makeTemplate58FromScratch, appendRows58 } = require('./src/templateBuilder');

module.exports = defineConfig({
  e2e: {
    specPattern: 'cypress/e2e/**/*.feature',
    supportFile: false,
    setupNodeEvents(on, config) {
      on('task', {
        async 'template:build'({ outName = 'CLINICAL_INTENT.xlsx' } = {}) {
          const outDir = path.join(__dirname, 'cypress', 'downloads');
          const fullPath = await makeTemplate58FromScratch({ outDir, outName });
          return { outDir, outName, fullPath };
        },
        async 'template:append'({ filePath, rows = [] }) {
          const fullPath = await appendRows58(filePath, rows);
          return { fullPath, appended: rows.length };
        }
      });
      return config;
    }
  }
});
