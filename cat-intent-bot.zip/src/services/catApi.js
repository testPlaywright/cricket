export async function uploadToCAT(filePath, meta) {
  if (!process.env.CAT_BASE_URL) throw new Error('CAT_BASE_URL not set; tickets API disabled in POC');
  return `upload-${Date.now()}`;
}
export async function createTicket(uploadId, meta) {
  if (!process.env.CAT_BASE_URL) throw new Error('CAT_BASE_URL not set; tickets API disabled in POC');
  return `CAT${String(Date.now()).slice(-7)}`;
}
export async function getTicket(id) {
  if (!process.env.CAT_BASE_URL) throw new Error('CAT_BASE_URL not set; tickets API disabled in POC');
  return { id, status: 'STUB' };
}
