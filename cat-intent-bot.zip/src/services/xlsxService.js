import fs from 'fs';
import XlsxPopulate from 'xlsx-populate';

export async function ensureOutDir(dir) {
  await fs.promises.mkdir(dir, { recursive: true });
}

const norm = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');

export async function cloneTemplate(templatePath, outPath) {
  if (!fs.existsSync(templatePath)) throw new Error(`Golden template not found at ${templatePath}`);
  await fs.promises.copyFile(templatePath, outPath);
  return outPath;
}

function findHeaderRow(sheet, maxScanRows = 40) {
  let bestRow = 0;
  let bestScore = -1;
  for (let r = 1; r <= maxScanRows; r++) {
    let score = 0;
    for (let c = 1; c <= 300; c++) {
      const v = sheet.cell(r, c).value();
      if (v && /[A-Za-z]/.test(String(v))) score++;
    }
    if (score > bestScore) { bestScore = score; bestRow = r; }
  }
  if (!bestRow) throw new Error('Could not detect header row');
  return bestRow;
}

function buildHeaderMap(sheet, headerRow) {
  const map = {};
  for (let c = 1; c <= 300; c++) {
    const v = sheet.cell(headerRow, c).value();
    if (!v) continue;
    const key = norm(String(v));
    map[key] = c;
  }
  return map;
}

function findFirstEmptyRow(sheet, headerRow) {
  let r = headerRow + 1;
  while (true) {
    const any = sheet.row(r).cells().some(cell => {
      const v = cell.value();
      return v !== null && v !== undefined && String(v) !== '';
    });
    if (!any) return r;
    r++;
    if (r > 20000) throw new Error('No empty row found; capped at 20k');
  }
}

export async function appendRows58({ filePath, rows = [], sheetName = 'CAT Automated' }) {
  const wb = await XlsxPopulate.fromFileAsync(filePath);
  const sheet = wb.sheet(sheetName) || wb.sheets()[0];

  const headerRow = findHeaderRow(sheet);
  const headerMap = buildHeaderMap(sheet, headerRow);
  let r = findFirstEmptyRow(sheet, headerRow);

  for (const row of rows) {
    for (const [k, v] of Object.entries(row || {})) {
      const col = headerMap[norm(k)];
      if (!col) { console.warn('Header not found in sheet:', k); continue; }
      sheet.cell(r, col).value(v);
    }
    r++;
  }

  await wb.toFileAsync(filePath);
  return filePath;
}
