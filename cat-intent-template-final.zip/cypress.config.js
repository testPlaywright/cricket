const { defineConfig } = require('cypress');
const fs = require('fs');
const path = require('path');
const ExcelJS = require('exceljs');
const cucumber = require('cypress-cucumber-preprocessor').default;

const { queryDb } = require('./cypress/plugins/ConnectDB.cjs');
const {
  makeTemplate58FromScratch,
  appendRows58
} = require('./src/templateBuilder.js');

const envJson = JSON.parse(
  fs.readFileSync('cypress.env.json', 'utf-8')
);

module.exports = defineConfig({
  defaultCommandTimeout: 300000,
  reporter: 'cypress-mochawesome-reporter',
  reporterOptions: {
    charts: true,
    json: true,
    saveJson: true,
    reportDir: process.env.REPORT_PATH,
    overwrite: false,
    reportFilename: 'index',
    reportPageTitle: 'CAT Automation Report',
    reportTitle: 'CAT Automation Regression Report',
    inlineAssets: true,
    html: true,
    saveHtml: true,
    embeddedScreenshots: true,
    saveAllAttempts: false
  },
  'cypress-cucumber-preprocessor': {
    nonGlobalStepDefinitions: true,
    stepDefinitions: './cypress/e2e/stepdefinitions/'
  },
  e2e: {
    specPattern: 'cypress/e2e/**/*.feature',
    supportFile: 'cypress/support/e2e.js',
    chromeWebSecurity: false,
    experimentalRunAllSpecs: true,
    experimentalSessionAndOrigin: true,

    setupNodeEvents(on, config) {
      require('cypress-mochawesome-reporter/plugin')(on);
      on('file:preprocessor', cucumber());

      on('task', {
        async 'template:build'({ outName = 'CLINICAL_INTENT.xlsx' } = {}) {
          const outDir = path.join(__dirname, 'cypress', 'downloads');
          if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
          const fullPath = await makeTemplate58FromScratch({ outDir, outName });
          return { outDir, outName, fullPath };
        },
        async 'template:append'({ filePath, rows = [] }) {
          const count = await appendRows58({ filePath, rows });
          return { fullPath: filePath, appended: count };
        },
        queryDb({ query, values }) {
          return queryDb(query, values);
        },
        async readErrorExcelExcelJS(fileName) {
          const filePath = path.join(__dirname, 'cypress/downloads', fileName);
          const workbook = new ExcelJS.Workbook();
          await workbook.xlsx.readFile(filePath);
          const sheet = workbook.getWorksheet('ValidationErrors') || workbook.worksheets[0];
          const rows = [];
          sheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
            if (rowNumber === 1) return;
            rows.push({
              ticketId: row.getCell(1).value,
              field: row.getCell(4).value,
              errorMessage: row.getCell(6).value
            });
          });
          return rows;
        }
      });
      return config;
    },

    env: {
      BASE_URL: process.env.BASE_URL,
      uploadFileName: envJson.uploadFileName,
      TAGS: 'not @ignore'
    },
    retries: 1
  }
});
