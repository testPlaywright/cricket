// Build the 58-field template from scratch + append rows
const fs = require('fs');
const path = require('path');
const XlsxPopulate = require('xlsx-populate');

// 58 headers from user spec (keep exact text)
const DEFAULT_HEADERS = [
  "PDLM Template Row #","Edit Type","BOM Analyst Attention Flag","List IDs",
  "LOB Codes to Apply","Exclusion LOB Codes to Apply","PEX LOB Codes to Apply",
  "Effective Date","Thru Date","Apply Monthly Rolling Dates",
  "Product Type (NDC, GPI)","Product ID","MSC","Coverage Decision","Drug Status",
  "OTC","Pckg","ROA","GPI List Edit","Use Benefit Reset","Drug Status Table",
  "Message Code","Message Text","Message Type","CT Logic","CT Effective Date",
  "CT Thru Date","CT Schedule ID","Bypass CT","Sequence","Age Min","Age Min Unit",
  "Age Max","Age Max Unit","Gender","Bypass Drug Status","Bypass MSC",
  "Mandate States","MandateOption","Mandate Instructions","TOC Batch Lists",
  "Clinical Rule","31 Days and Under","31 Days and Under PQE",
  "31 Days and Under PQE Max","35 Days and Over","35 Days and Over PQE",
  "35 Days and Over PQE Max","P&G 120 Days Supply Limit","P&G 120 Days PQE",
  "P&G 120 Days PQE Max","Specialty","Client Options","Dx2Rx List",
  "Dx2Rx List Qualifier","Dx2Rx List Status","Dx2Rx Message Schedule",
  "Dx2Rx Message Schedule Type"
];

const TOP_LABELS = [
  "Segment","Version","Template","Action","Cycle","Priority",
  "Template Code","PEX LOB","PEXL OB Codes","Custom PEX Search",
  "Custom PEX Plan Desc Filter","Custom PEX LPI Filter"
];

function norm(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/[^\w]+/g,'')    // remove spaces/punct
    .replace(/_/g,'');
}

async function makeTemplate58FromScratch(outDir, outName='CLINICAL_INTENT.xlsx') {
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

  const wb = await XlsxPopulate.fromBlankAsync();
  // Remove default extra sheets, keep one named 'CAT Automated'
  const sheet = wb.sheet(0);
  sheet.name('CAT Automated');

  // Column widths
  for (let c = 1; c <= DEFAULT_HEADERS.length; c++) {
    sheet.column(c).width(18);
  }

  // Row 2: top labels (light green)
  for (let i=0; i<TOP_LABELS.length; i++) {
    const cell = sheet.cell(2, i+1);
    cell.value(TOP_LABELS[i]);
    cell.style({
      bold: true,
      fill: '9CCC65', // green-ish
      fontColor: '000000',
      horizontalAlignment: 'center'
    });
  }

  // Row 3: sample values (as seen in screenshots)
  const TOP_VALUES = [
    "E&I","V3.2","Essential","ADD","On-Cycle","Standard",
    "TEMGRULE","","","","",""
  ];
  for (let i=0; i<TOP_VALUES.length; i++) {
    sheet.cell(3, i+1).value(TOP_VALUES[i]);
  }

  // Row 4: numbering (1..n) for first 12 only to match look
  for (let i=0; i<TOP_LABELS.length; i++) {
    sheet.cell(4, i+1).value(i+1).style({ italic: true, fontColor: '666666' });
  }

  // Header row (bold black with green band like)
  const headerRowIndex = 7; // leave a gap like template does
  for (let i=0; i<DEFAULT_HEADERS.length; i++) {
    const cell = sheet.cell(headerRowIndex, i+1);
    cell.value(DEFAULT_HEADERS[i]);
    cell.style({
      bold: true,
      fill: '263238',        // dark band
      fontColor: 'FFFFFF',
      horizontalAlignment: 'center'
    });
    // thin border bottom
    cell.style({ bottomBorder: true });
  }

  // Sub header labels one row below (row 8) same texts but lighter band
  const subIndex = headerRowIndex + 1;
  for (let i=0; i<DEFAULT_HEADERS.length; i++) {
    const cell = sheet.cell(subIndex, i+1);
    cell.value(DEFAULT_HEADERS[i].replace(/\s+/g,''));
    cell.style({
      bold: true,
      fill: 'A5D6A7',        // light green band
      horizontalAlignment: 'center'
    });
  }

  // save
  const full = path.join(outDir, outName);
  await wb.toFileAsync(full);
  return full;
}

function buildHeaderMap(sheet, headerRow) {
  const map = {};
  for (let c=1; c<=300; c++) {
    const v = sheet.cell(headerRow, c).value();
    if (!v) break;
    map[norm(v)] = c;
  }
  return map;
}

function findHeaderRow(sheet) {
  for (let r=1; r<=20; r++) {
    const v1 = norm(sheet.cell(r,1).value());
    const v2 = norm(sheet.cell(r,2).value());
    if (v1.includes('pdlmtemplaterow') || (v1.includes('pdlm') && v2.includes('edittype'))) {
      return r;
    }
  }
  // fallback default where we placed it
  return 7;
}

function firstEmptyRow(sheet, headerRow) {
  let r = headerRow + 2; // skip band row below
  while (true) {
    const rowEmpty = sheet.row(r).cell(1).value() == null &&
      sheet.row(r).cell(2).value() == null &&
      sheet.row(r).cell(3).value() == null &&
      sheet.row(r).cell(4).value() == null;
    if (rowEmpty) return r;
    r++;
    if (r>50000) throw new Error('No empty row found');
  }
}

async function appendRows58(filePath, rows = []) {
  const wb = await XlsxPopulate.fromFileAsync(filePath);
  const sheet = wb.sheet('CAT Automated') || wb.sheets()[0];

  const headerRow = findHeaderRow(sheet);
  const map = buildHeaderMap(sheet, headerRow);

  let r = firstEmptyRow(sheet, headerRow);

  (rows || []).forEach(inRow => {
    const entries = Object.entries(inRow || {});
    // Always set Edit Type / PDLM if not present
    if (!('Edit Type' in inRow) && !('EditType' in inRow)) {
      entries.push(['Edit Type','VALID']);
    }
    entries.forEach(([k,v]) => {
      const col = map[norm(k)];
      if (!col) {
        // skip unknowns silently
        return;
      }
      sheet.cell(r, col).value(v == null ? '' : String(v));
    });
    r++;
  });

  await wb.toFileAsync(filePath);
  return filePath;
}

module.exports = {
  makeTemplate58FromScratch,
  appendRows58,
  DEFAULT_HEADERS
};