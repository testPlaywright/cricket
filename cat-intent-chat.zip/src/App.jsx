import React from 'react'
import ChatWidget from './ChatWidget.jsx'

export default function App() {
  return (
    <div className="page">
      <header className="header">
        <h1>CAT Intent Assistant</h1>
        <p className="subtitle">Create Clinical Intent files or submit tickets via chat.</p>
      </header>
      <div className="content">
        <ChatWidget />
      </div>
      <footer className="footer">
        <small>POC · Uses your CAT Intent Bot backend</small>
      </footer>
    </div>
  )
}
