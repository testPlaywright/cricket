const XlsxPopulate = require('xlsx-populate');
const path = require('path');
const fs = require('fs');

async function makeTemplate58FromScratch({ outDir, outName }) {
  const wb = await XlsxPopulate.fromBlankAsync();
  const sheet = wb.sheet(0).name('CAT Automated');

  // minimal header row for demo
  const headers = ["PDLM Template Row #","Edit Type","Product ID","Product Type","List IDs","LOB Codes to Apply"];
  headers.forEach((h,i)=>sheet.cell(4,i+1).value(h).style("bold",true));

  const fullPath = path.join(outDir, outName);
  await wb.toFileAsync(fullPath);
  return fullPath;
}

async function appendRows58({ filePath, rows }) {
  const wb = await XlsxPopulate.fromFileAsync(filePath);
  const sheet = wb.sheet('CAT Automated') || wb.sheet(0);
  let startRow = sheet.usedRange().endCell().rowNumber() + 1;
  rows.forEach(r => {
    Object.values(r).forEach((val,idx)=>{
      sheet.cell(startRow, idx+1).value(val);
    });
    startRow++;
  });
  await wb.toFileAsync(filePath);
  return rows.length;
}

module.exports = { makeTemplate58FromScratch, appendRows58 };
