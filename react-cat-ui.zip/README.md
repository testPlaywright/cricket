# Clinical Intent Builder (React + Node)

Monorepo-style layout with a shared schema used by both frontend and backend.

```
react-cat-ui/
├─ frontend/        # Vite + React + TS (runs on :5173)
├─ backend/         # Express + TS (runs on :5179)
└─ shared/          # Zod schemas shared across packages
```

## Quick Start

### 1) Backend
```
cd backend
npm install
npm run dev
```
(Starts Express on :5179)

### 2) Frontend
```
cd ../frontend
npm install
npm run dev
```
Open http://localhost:5173

The Vite dev server proxies **/api** calls to the backend (:5179) automatically.

## Building Excel
- Press **Add row** to add a row (uses the 5 quick fields).
- **Download Excel** creates an .xlsx with (placeholder) 7 headers; plug your full 58 headers later.
- **Create Ticket** posts rows to `/api/tickets` (currently mocked, returns a fake jobId).

## TODO
- Replace `HEADERS_58` with your real 58 headers (both frontend & backend).
- Implement actual CAT upload in backend `/api/tickets` route.
- Add authentication (OIDC/JWT) if needed.
