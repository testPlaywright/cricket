const { Given, When, Then } = require('cypress-cucumber-preprocessor/steps');

let filePath;

Given('I build a fresh 58-field template', () => {
  cy.task('template:build', { outName:'CLINICAL_INTENT.xlsx' }).then(res=>{
    filePath=res.fullPath;
    cy.wrap(filePath).as('intentPath');
  });
});

When('I append these rows:', (dataTable) => {
  cy.get('@intentPath').then((fp)=>{
    const rows=dataTable.hashes();
    cy.task('template:append',{filePath:fp,rows});
  });
});

Then('the template should exist', () => {
  cy.readFile(filePath,'binary',{timeout:20000}).should('exist');
});
