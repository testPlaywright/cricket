import { z } from 'zod';

export const RowSchema = z.object({
  productId: z.string().min(5),
  editType: z.enum(['VALID','INVALID']),
  productType: z.enum(['NDC','GPI']),
  listIds: z.string().min(1),
  lobCodes: z.string().min(1),
  effectiveDate: z.string().optional(),
});

export type IntentRow = z.infer<typeof RowSchema>;

export const PayloadSchema = z.object({
  rows: z.array(RowSchema).min(1).max(5000),
  mode: z.enum(['single','bulk']),
  source: z.enum(['ui','file','api']).default('ui')
});
