import express from 'express';
const router = express.Router();

router.post('/create', async (req, res) => {
  try {
    // stub: just echo
    return res.json({ ok: true, ticket: { id: 'TICKET-123', ...req.body } });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

export default router;
