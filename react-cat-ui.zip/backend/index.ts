import express from 'express';
import cors from 'cors';
import * as XLSX from 'xlsx';
import { PayloadSchema } from '../shared/schema';
import { v4 as uuid } from 'uuid';

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));

const HEADERS_58 = [
  'PDLM Template Row #','Edit Type','List IDs','LOB Codes to Apply',
  'Product Type','Product ID','EffectiveDate'
];

app.get('/health', (_req, res) => res.json({ ok: true }));

app.post('/api/tickets', async (req, res) => {
  const parsed = PayloadSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.message });
  const { rows } = parsed.data;

  const fullRows = rows.map((r, i) => ({
    'PDLM Template Row #': i+1,
    'Edit Type': r.editType,
    'List IDs': r.listIds,
    'LOB Codes to Apply': r.lobCodes,
    'Product Type': r.productType,
    'Product ID': r.productId,
    'EffectiveDate': r.effectiveDate ?? new Date().toISOString().slice(0,10),
  }));

  const ws = XLSX.utils.json_to_sheet(fullRows, { header: HEADERS_58 });
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'ClinicalIntent');
  const xlsxBuffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

  // TODO: Replace with actual CAT upload call.
  return res.json({ jobId: uuid(), ticketId: 'CAT12345' });
});

const PORT = Number(process.env.PORT || 5179);
app.listen(PORT, () => console.log(`API running on :${PORT}`));
