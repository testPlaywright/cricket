import React, { useMemo, useState } from 'react'

const API = import.meta.env.VITE_API_URL || 'http://localhost:30000';

function Bubble({ from, children }){
  return <div className={'bubble '+(from==='bot'?'bot':'user')}>{children}</div>
}

export default function ChatApp(){
  const [msgs, setMsgs] = useState([
    { from:'bot', text:'Hi! I can create a Clinical Intent file or submit a ticket.' },
    { from:'bot', text:'Fill the fields and click Generate XLSX or Create Ticket.' }
  ]);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    'Edit Type': 'VALID',
    'Product Type (NDC, GPI)': 'NDC',
    'Product ID': '7000000002',
    'List IDs': 'LIST3',
    'LOB Codes to Apply': 'MPL1'
  });
  const [status, setStatus] = useState('');

  const rowsPayload = useMemo(()=>[form],[form]);
  const onChange = (k,v)=> setForm(prev => ({ ...prev, [k]: v }));

  async function generateXlsx(){
    setBusy(true); setStatus('Generating…'); setMsgs(m=>[...m,{from:'user',text:'Generate XLSX'}]);
    try{
      const res = await fetch(`${API}/templates/generate`,{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ fileName:'CLINICAL_INTENT.xlsx', rows: rowsPayload })
      });
      if(!res.ok) throw new Error('HTTP '+res.status);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = 'CLINICAL_INTENT.xlsx';
      document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
      setMsgs(m=>[...m,{from:'bot',text:'Your file is ready — downloaded as CLINICAL_INTENT.xlsx'}]);
      setStatus('Done.');
    }catch(e){
      setMsgs(m=>[...m,{from:'bot',text:'Sorry, failed to generate. '+e.message}]);
      setStatus('Failed.');
    }finally{ setBusy(false); }
  }

  async function createTicket(){
    setBusy(true); setStatus('Creating ticket…'); setMsgs(m=>[...m,{from:'user',text:'Create Ticket'}]);
    try{
      const res = await fetch(`${API}/templates/create-ticket`,{ method:'POST' });
      const data = await res.json();
      setMsgs(m=>[...m,{from:'bot',text:`Ticket created: ${data.ticketId || 'N/A'}` }]);
      setStatus('Ticket created.');
    }catch(e){
      setMsgs(m=>[...m,{from:'bot',text:'Sorry, failed to create. '+e.message}]);
      setStatus('Failed.');
    }finally{ setBusy(false); }
  }

  return (
    <div className="wrap">
      <h2>CAT Intent Assistant</h2>
      <div className="panel">
        {msgs.map((m,i)=>(<Bubble key={i} from={m.from}>{m.text}</Bubble>))}
        <div className="div"></div>

        <div className="form">
          <div className="group">
            <label>Edit Type *</label>
            <input value={form['Edit Type']||''} onChange={(e)=>onChange('Edit Type', e.target.value)} />
          </div>
          <div className="group">
            <label>Product Type *</label>
            <select value={form['Product Type (NDC, GPI)']||'NDC'} onChange={(e)=>onChange('Product Type (NDC, GPI)', e.target.value)}>
              <option value="NDC">NDC</option>
              <option value="GPI">GPI</option>
            </select>
          </div>
          <div className="group">
            <label>Product ID *</label>
            <input value={form['Product ID']||''} onChange={(e)=>onChange('Product ID', e.target.value)} />
          </div>
          <div className="group">
            <label>List IDs</label>
            <input value={form['List IDs']||''} onChange={(e)=>onChange('List IDs', e.target.value)} />
          </div>
          <div className="group">
            <label>LOB Codes to Apply</label>
            <input value={form['LOB Codes to Apply']||''} onChange={(e)=>onChange('LOB Codes to Apply', e.target.value)} />
          </div>
        </div>

        <div className="actions">
          <button disabled={busy} onClick={generateXlsx}>Generate XLSX</button>
          <button disabled={busy} onClick={createTicket}>Create Ticket</button>
        </div>

        {status && <div className="result">{status}</div>}
      </div>
      <small style={{opacity:.7}}>POC • Talks to your backend at {API}</small>
    </div>
  )
}
