// src/templateSchema.js
exports.meta = {
  row1: ['Segment','Version','Template','Action','Cycle','Priority','Template Code','PEX LOB','PEX LOB Codes','Custom PEX Search','Custom PEX Plan Desc Filter','Custom PEX LN Filter'],
  row2: ['E&I','V3.2','Essential','ADD','On-Cycle','Standard','TEMGRULE','','','','',''],
  row3: ['1','2','3','4','5','6','7','8','9','10','11','12']
};

exports.headers58 = [
  'PDLM Template Row #','Edit Type','BOM Analyst Attention Flag','List IDs','LOB Codes to Apply',
  'Exclusion LOB Codes to Apply','PEX LOB Codes to Apply','Effective Date','Thru Date',
  'Apply Monthly Rolling Dates','Product Type (NDC, GPI)','Product ID','MSC','Coverage Decision',
  'Drug Status','OTC','Pckg','ROA','GPI List Edit','Use Benefit Reset','Drug Status Table',
  'Message Code','Message Text','Message Type','CT Logic','CT Effective Date','CT Thru Date',
  'CT Schedule ID','Bypass CT','Sequence','Age Min','Age Min Unit','Age Max','Age Max Unit',
  'Gender','Bypass Drug Status','Bypass MSC','Mandate States','MandateOption','Mandate Instructions',
  'TOC Batch Lists','Clinical Rule','31 Days and Under','31 Days and Under PQE',
  '31 Days and Under PQE Max','35 Days and Over','35 Days and Over PQE','35 Days and Over PQE Max',
  'P&G 120 Days Supply Limit','P&G 120 Days PQE','P&G 120 Days PQE Max','Specialty','Client Options',
  'Dx2Rx List','Dx2Rx List Qualifier','Dx2Rx List Status','Dx2Rx Message Schedule',
  'Dx2Rx Message Schedule Type'
];
