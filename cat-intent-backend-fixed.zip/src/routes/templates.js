import express from 'express';
import XlsxPopulate from 'xlsx-populate';
import path from 'path';
import fs from 'fs';

const router = express.Router();
const TEMPLATE_PATH = path.join(process.cwd(), 'backend', 'golden_template.xlsx');

const norm = s => String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');

function buildHeaderMap(sheet, headerRow) {
  const map = {};
  const lastCol = sheet.usedRange().endCell().columnNumber();
  for (let c = 1; c <= lastCol; c++) {
    const raw = sheet.cell(headerRow, c).value();
    if (raw == null || String(raw).trim() === '') continue;
    const key = norm(String(raw).replace(/\n/g, ' '));
    map[key] = c;
  }
  return map;
}

function firstEmptyRow(sheet, headerRow) {
  const lastCol = sheet.usedRange().endCell().columnNumber();
  let r = headerRow + 1;
  while (true) {
    let anyVal = false;
    for (let c = 1; c <= lastCol; c++) {
      const v = sheet.cell(r, c).value();
      if (v !== null && v !== undefined && String(v).trim() !== '') {
        anyVal = true;
        break;
      }
    }
    if (!anyVal) return r;
    r++;
    if (r > 50000) throw new Error('No empty row found (capped at 50k rows)');
  }
}

function appendRows(sheet, headerRow, headers, rows) {
  const headerMap = buildHeaderMap(sheet, headerRow);
  const startRow = firstEmptyRow(sheet, headerRow);
  rows.forEach((rowObj, idx) => {
    const r = startRow + idx;
    headers.forEach((h, i) => {
      const key = norm(h.name.replace(/\n/g, ' '));
      const col = headerMap[key] || (i + 1);
      const val = rowObj[h.name] ?? rowObj[key] ?? '';
      sheet.cell(r, col).value(val);
    });
  });
}

router.post('/generate', async (req, res) => {
  try {
    const { rows, outName = 'intent_output.xlsx' } = req.body;
    if (!rows || !Array.isArray(rows)) {
      return res.status(400).json({ error: 'rows array required' });
    }

    if (!fs.existsSync(TEMPLATE_PATH)) {
      return res.status(500).json({ error: 'Golden template missing' });
    }

    const wb = await XlsxPopulate.fromFileAsync(TEMPLATE_PATH);
    const ws = wb.sheet('CAT Automated');
    const headerRow = 8; // adjust if headers differ

    const DEFAULT_HEADERS = ws.row(headerRow).cells().map(c => ({ name: c.value() }));

    appendRows(ws, headerRow, DEFAULT_HEADERS, rows);

    const tmpOut = path.join(process.cwd(), 'backend', 'tmp');
    if (!fs.existsSync(tmpOut)) fs.mkdirSync(tmpOut, { recursive: true });
    const outPath = path.join(tmpOut, outName);
    await wb.toFileAsync(outPath);

    return res.json({ ok: true, file: outPath });
  } catch (err) {
    console.error('Error in /templates/generate:', err);
    return res.status(500).json({ error: err.message });
  }
});

export default router;
