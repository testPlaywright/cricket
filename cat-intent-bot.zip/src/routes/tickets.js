import express from 'express';
import { uploadToCAT, createTicket, getTicket } from '../services/catApi.js';
import path from 'path';
import { fileURLToPath } from 'url';
import { ensureOutDir, cloneTemplate, appendRows58 } from '../services/xlsxService.js';

const router = express.Router();

router.post('/', async (req, res, next) => {
  try {
    const rows = Array.isArray(req.body?.rows) ? req.body.rows : [];
    const meta = req.body?.meta || {};

    const __filename = fileURLToPath(import.meta.url);
    const __dirname = path.dirname(__filename);
    const templatePath = path.join(__dirname, '..', '..', 'fixtures', 'intentTemplate.xlsx');
    const outPath = path.join(__dirname, '..', '..', `CLINICAL_INTENT_${Date.now()}.xlsx`);

    await ensureOutDir(path.dirname(outPath));
    const filePath = await cloneTemplate(templatePath, outPath);
    await appendRows58({ filePath, rows });

    const uploadId = await uploadToCAT(filePath, meta);
    const ticketId = await createTicket(uploadId, meta);
    res.json({ ticketId });
  } catch (e) { next(e); }
});

router.get('/:id', async (req, res, next) => {
  try {
    res.json(await getTicket(req.params.id));
  } catch (e) { next(e); }
});

export default router;
