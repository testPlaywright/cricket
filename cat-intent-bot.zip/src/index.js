import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import dotenv from 'dotenv';

import templatesRouter from './routes/templates.js';
import ticketsRouter from './routes/tickets.js';

dotenv.config();

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(morgan('dev'));
app.use(cors());

app.get('/healthz', (_req, res) => res.json({ ok: true }));
app.use('/templates', templatesRouter);
app.use('/tickets', ticketsRouter);

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`CAT Intent Bot listening on :${port}`));
