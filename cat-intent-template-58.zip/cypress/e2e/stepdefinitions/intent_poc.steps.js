const { Given, When, Then } = require('@badeball/cypress-cucumber-preprocessor');

let outPath;

Given('I build a fresh 58-field template', () => {
  cy.task('template:build', { outName: 'CLINICAL_INTENT.xlsx' }).then(r => {
    outPath = r.fullPath;
    cy.wrap(outPath, { log: true }).as('intentPath');
  });
});

When('I append these rows into the intent file', (table) => {
  const rows = table.hashes();
  cy.get('@intentPath').then((filePath) => {
    cy.task('template:append', { filePath, rows });
  });
});

Then('the intent file should exist', () => {
  cy.get('@intentPath').then((filePath) => {
    cy.readFile(filePath, 'binary', { log:false }).should('exist');
  });
});