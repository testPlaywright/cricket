const { Given } = require('@badeball/cypress-cucumber-preprocessor');

Given('I build a fresh 58-field template', () => {
  cy.task('template:build', { outName: 'CLINICAL_INTENT.xlsx' })
    .then(res => {
      expect(res.fullPath).to.include('CLINICAL_INTENT.xlsx');
    });
});
