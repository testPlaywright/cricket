# CAT Intent Assistant (Chat) – Full Stack

- backend/: Express API
  - POST /templates/generate -> returns XLSX
  - POST /templates/create-ticket -> returns mock ticketId
- frontend/: React chat-like UI

## Run
1) Backend
```
cd backend
cp .env.example .env
npm i
npm run dev
```
2) Frontend
```
cd frontend
cp .env.example .env
npm i
npm run dev
```
