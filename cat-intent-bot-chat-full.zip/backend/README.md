# Chat Backend
- POST `/templates/generate` -> returns XLSX
- POST `/templates/create-ticket` -> returns mock ticketId
Run: `npm i && cp .env.example .env && npm run dev` (port 30000)
