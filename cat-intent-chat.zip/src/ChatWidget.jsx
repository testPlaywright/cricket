import React, { useMemo, useRef, useState } from 'react'

const API_BASE = import.meta.env.VITE_BOT_BASE || 'http://localhost:3000'

const REQUIRED = [
  { key: 'Edit Type', label: 'Edit Type', placeholder: 'INVALID or VALID' },
  { key: 'Product Type (NDC, GPI)', label: 'Product Type', placeholder: 'NDC or GPI' },
  { key: 'Product ID', label: 'Product ID', placeholder: 'e.g., 7000000002' },
]

const OPTIONAL = [
  { key: 'List IDs', label: 'List IDs', placeholder: 'LIST1;LIST2', help: 'semicolon-separated' },
  { key: 'LOB Codes to Apply', label: 'LOB Codes to Apply', placeholder: 'MPL1', help: '' },
]

function Bubble({ from, children }) {
  return (
    <div className={'bubble ' + (from === 'bot' ? 'bot' : 'user')}>
      {children}
    </div>
  )
}

function Divider() {
  return <div className="divider"></div>
}

export default function ChatWidget() {
  const [messages, setMessages] = useState([
    { from: 'bot', text: 'Hi! I can create a Clinical Intent file or submit a ticket. What would you like to do?' },
    { from: 'bot', text: 'Provide the fields below and click **Generate XLSX** or **Create Ticket**.' },
  ])
  const [form, setForm] = useState({ mode: 'generate' })
  const [busy, setBusy] = useState(false)
  const [downloadUrl, setDownloadUrl] = useState('')
  const [ticketId, setTicketId] = useState('')

  const formRef = useRef(null)

  const rowsPayload = useMemo(() => {
    const row = {}
    for (const f of REQUIRED) {
      if (form[f.key]) row[f.key] = form[f.key]
    }
    for (const f of OPTIONAL) {
      if (form[f.key]) row[f.key] = form[f.key]
    }
    return [row]
  }, [form])

  const addBot = (text) => setMessages(m => [...m, { from: 'bot', text }])
  const addUser = (text) => setMessages(m => [...m, { from: 'user', text }])

  async function handleGenerate() {
    setBusy(true)
    setDownloadUrl('')
    setTicketId('')
    addUser('Generate XLSX')
    try {
      const res = await fetch(`${API_BASE}/templates/clinical-intent`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName: `CLINICAL_INTENT_${Date.now()}.xlsx`, rows: rowsPayload })
      })
      if (!res.ok) throw new Error('Failed to generate file')
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      setDownloadUrl(url)
      addBot('Your file is ready. Click the download button below.')
    } catch (e) {
      console.error(e)
      addBot('Sorry, I could not generate the file.')
    } finally {
      setBusy(false)
    }
  }

  async function handleCreateTicket() {
    setBusy(true)
    setDownloadUrl('')
    setTicketId('')
    addUser('Create Ticket')
    try {
      const res = await fetch(`${API_BASE}/tickets`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rows: rowsPayload, meta: {} })
      })
      if (!res.ok) throw new Error('Failed to create ticket')
      const data = await res.json()
      setTicketId(data.ticketId || 'UNKNOWN')
      addBot(`Ticket created: **${data.ticketId || 'UNKNOWN'}**`)
    } catch (e) {
      console.error(e)
      addBot('Sorry, I could not create the ticket (check backend CAT credentials).')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="chatwrap">
      <div className="chat">
        {messages.map((m, i) => (
          <Bubble key={i} from={m.from}>
            <span dangerouslySetInnerHTML={{ __html: m.text.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>') }} />
          </Bubble>
        ))}
        <Divider />
        <form ref={formRef} className="form" onSubmit={(e) => e.preventDefault()}>
          <div className="group">
            <label>Action</label>
            <select value={form.mode} onChange={(e) => setForm({ ...form, mode: e.target.value })}>
              <option value="generate">Generate XLSX</option>
              <option value="ticket">Create Ticket</option>
            </select>
          </div>

          <div className="grid">
            {REQUIRED.map(f => (
              <div className="group" key={f.key}>
                <label>{f.label} <span className="req">*</span></label>
                <input
                  placeholder={f.placeholder}
                  value={form[f.key] || ''}
                  onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                />
              </div>
            ))}
            {OPTIONAL.map(f => (
              <div className="group" key={f.key}>
                <label>{f.label}</label>
                <input
                  placeholder={f.placeholder}
                  value={form[f.key] || ''}
                  onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                />
                {f.help ? <small className="hint">{f.help}</small> : null}
              </div>
            ))}
          </div>

          <div className="actions">
            <button type="button" disabled={busy} onClick={handleGenerate}>Generate XLSX</button>
            <button type="button" disabled={busy} onClick={handleCreateTicket}>Create Ticket</button>
          </div>

          {downloadUrl && (
            <div className="result">
              <a href={downloadUrl} download>⬇️ Download CLINICAL_INTENT.xlsx</a>
            </div>
          )}
          {ticketId && (
            <div className="result">
              <span>✅ Ticket ID: <b>{ticketId}</b></span>
            </div>
          )}
        </form>
      </div>
    </div>
  )
}
