import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { ensureOutDir, cloneTemplate, appendRows58 } from '../services/xlsxService.js';

const router = express.Router();

router.post('/clinical-intent', async (req, res, next) => {
  try {
    const rows = Array.isArray(req.body?.rows) ? req.body.rows : [];
    const outName = req.body?.fileName || `CLINICAL_INTENT_${Date.now()}.xlsx`;

    const __filename = fileURLToPath(import.meta.url);
    const __dirname = path.dirname(__filename);
    const templatePath = path.join(__dirname, '..', '..', 'fixtures', 'intentTemplate.xlsx');
    const outPath = path.join(__dirname, '..', '..', outName);

    await ensureOutDir(path.dirname(outPath));
    const filePath = await cloneTemplate(templatePath, outPath);
    await appendRows58({ filePath, rows });

    res.download(filePath, outName);
  } catch (e) { next(e); }
});

export default router;
