# Chat Frontend
Run:
```bash
cd frontend
cp .env.example .env
npm i
npm run dev
```
Open http://localhost:5173 — it will call your backend at VITE_API_URL.
