# CAT Intent Bot (POC)

Generate **CLINICAL_INTENT.xlsx** from JSON rows (58 fields), preserving formatting by
cloning your golden template and writing values by header name.

## Setup
```bash
npm i
cp .env.example .env
# copy your golden template to fixtures/intentTemplate.xlsx
npm run dev
```

### API
- `POST /templates/clinical-intent` → returns the generated XLSX as a download.

Body:
```json
{ "fileName":"CLINICAL_INTENT.xlsx", "rows":[ { "Edit Type":"INVALID", "List IDs":"LIST3" } ] }
```

- `POST /tickets` and `GET /tickets/:id` are **stubs** until you wire CAT credentials + endpoints.
