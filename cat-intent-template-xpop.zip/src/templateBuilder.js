// src/templateBuilder.js
const fs = require('fs');
const path = require('path');
const XlsxPopulate = require('xlsx-populate');
const { meta, headers58 } = require('./templateSchema');

function norm(s){ return String(s||'').toLowerCase().replace(/\s+/g,' ').trim(); }

function setBandStyle(range){
  range.style({
    bold:true,
    fill:'000000',
    fontColor:'FFFFFF',
    horizontalAlignment:'center',
    verticalAlignment:'center',
    border:true
  });
}

async function makeTemplate58FromScratch({ outDir, outName='CLINICAL_INTENT.xlsx' }){
  if(!fs.existsSync(outDir)) fs.mkdirSync(outDir,{recursive:true});
  const outPath = path.join(outDir,outName);

  const wb = await XlsxPopulate.fromBlankAsync();
  const sh = wb.addSheet('CAT Automated');
  wb.deleteSheet('Sheet1');

  sh.cell(1,1).value(meta.row1);
  sh.cell(2,1).value(meta.row2);
  sh.cell(3,1).value(meta.row3);

  for(let r=4;r<=7;r++) sh.row(r).height(18);

  sh.cell(8,1).value(headers58);
  setBandStyle(sh.range(8,1,8,headers58.length));

  for(let c=1;c<=headers58.length;c++){
    sh.column(c).width(Math.max(12,Math.min(28,headers58[c-1].length+6)));
  }

  await wb.toFileAsync(outPath);
  return outPath;
}

function buildHeaderMap(sheet, headerRow=8){
  const map={};
  let c=1;
  while(true){
    const v=sheet.cell(headerRow,c).value();
    if(v==null||String(v).trim()==='') break;
    map[norm(v)] = c;
    c++;
  }
  return map;
}

function firstEmptyDataRow(sheet, headerRow=8){
  let r=headerRow+1;
  while(true){
    let any=false;
    for(let c=1;c<=headers58.length;c++){
      const v=sheet.cell(r,c).value();
      if(v!=null&&String(v).trim()!==''){ any=true; break; }
    }
    if(!any) return r;
    r++;
    if(r>50000) throw new Error('No empty row found');
  }
}

async function appendRows58(filePath, rows=[]){
  const wb = await XlsxPopulate.fromFileAsync(filePath);
  const sh = wb.sheet('CAT Automated')||wb.sheets()[0];
  const map=buildHeaderMap(sh,8);
  let r=firstEmptyDataRow(sh,8);
  (rows||[]).forEach(rowObj=>{
    Object.entries(rowObj||{}).forEach(([k,v])=>{
      const col=map[norm(k)];
      if(col) sh.cell(r,col).value(v==null?'':String(v));
    });
    r++;
  });
  await wb.toFileAsync(filePath);
  return filePath;
}

module.exports={ makeTemplate58FromScratch, appendRows58 };
