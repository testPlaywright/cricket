import { useState } from 'react';
import { saveAs } from 'file-saver';
import * as XLSX from 'xlsx';
import { RowSchema, PayloadSchema, type IntentRow } from 'shared/schema';

const HEADERS_58 = [
  'PDLM Template Row #','Edit Type','List IDs','LOB Codes to Apply',
  'Product Type','Product ID','EffectiveDate'
];

export default function App() {
  const [rows, setRows] = useState<IntentRow[]>([]);
  const [q, setQ] = useState<IntentRow>({
    productId: '', editType: 'VALID', productType: 'NDC',
    listIds: 'LISTS', lobCodes: 'MPL1'
  });

  const addQuickRow = () => {
    const parsed = RowSchema.safeParse(q);
    if (!parsed.success) { alert(parsed.error.issues[0].message); return; }
    setRows(prev => [...prev, parsed.data]);
  };

  const downloadExcel = () => {
    const fullRows = rows.map((r, i) => ({
      'PDLM Template Row #': i+1,
      'Edit Type': r.editType,
      'List IDs': r.listIds,
      'LOB Codes to Apply': r.lobCodes,
      'Product Type': r.productType,
      'Product ID': r.productId,
      'EffectiveDate': r.effectiveDate ?? new Date().toISOString().slice(0,10),
    }));
    const ws = XLSX.utils.json_to_sheet(fullRows, { header: HEADERS_58 });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'ClinicalIntent');
    const buf = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
    const file = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(file, `clinical_intent_${Date.now()}.xlsx`);
  };

  const createTicket = async () => {
    const parsed = PayloadSchema.safeParse({ rows, mode: 'single', source: 'ui' });
    if (!parsed.success) { alert(parsed.error.issues[0].message); return; }

    const res = await fetch('/api/tickets', {
      method: 'POST',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify(parsed.data)
    });
    const out = await res.json();
    if (!res.ok) { alert(out.error || 'Failed'); return; }
    alert(`Ticket job submitted. Job ID: ${out.jobId}`);
  };

  return (
    <main style={{ padding: 24 }}>
      <h2>Clinical Intent Builder</h2>
      <div style={{ display:'grid', gridTemplateColumns:'200px 200px 200px', gap:12 }}>
        <input placeholder="Product ID" value={q.productId} onChange={e=>setQ({...q, productId:e.target.value})}/>
        <select value={q.editType} onChange={e=>setQ({...q, editType:e.target.value as any})}>
          <option value="VALID">VALID</option>
          <option value="INVALID">INVALID</option>
        </select>
        <select value={q.productType} onChange={e=>setQ({...q, productType:e.target.value as any})}>
          <option value="NDC">NDC</option>
          <option value="GPI">GPI</option>
        </select>
        <input placeholder="List IDs" value={q.listIds} onChange={e=>setQ({...q, listIds:e.target.value})}/>
        <input placeholder="LOB Codes" value={q.lobCodes} onChange={e=>setQ({...q, lobCodes:e.target.value})}/>
        <button onClick={addQuickRow}>Add row</button>
      </div>
      <div style={{ marginTop: 12 }}>Rows ready: {rows.length}</div>
      <div style={{ display:'flex', gap:12, marginTop: 12 }}>
        <button onClick={downloadExcel}>Download Excel</button>
        <button onClick={createTicket}>Create Ticket</button>
      </div>
    </main>
  );
}
