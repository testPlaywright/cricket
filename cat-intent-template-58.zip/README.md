
# CAT Intent Template (58) — from scratch

## Install
```
npm i
```

## Run
Open Cypress and run the `intent_poc.feature` spec.

This creates `cypress/downloads/CLINICAL_INTENT.xlsx` with the 58 headers and appends multiple rows from the Scenario Outline.
